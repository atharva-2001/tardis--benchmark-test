
def main():  # pragma: no cover
    print("This will do something")